Thank you for giving me this opportunity. For the database structure. The database name is bank and it has the default login which is root and empty password. You can get the details in the conn.php file. No signup page to view data except login page. The login details already present is;
Username: ponmile
Passowrd: Adefuwa.

Thanks. My updated CV is included in the folder. Thank you.